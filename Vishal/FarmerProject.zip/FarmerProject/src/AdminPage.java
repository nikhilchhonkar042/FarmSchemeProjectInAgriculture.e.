import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import dao.CropDAO;
import entities.CropDetailsEntity;
import service.CropDAOImplementation;

import dao.BiddingDAO;
import entities.BiddingEntity;
import service.BiddingDAOImplementation;

import dao.FarmerDAO;
import entities.FarmerEntity;
import service.FarmerDAOImplementation;

import dao.BidderDAO;
import entities.BidderEntity;
import service.BidderDAOImplementation;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

public class AdminPage extends JFrame {

	private JPanel contentPane;
	private JTable table;
	DefaultTableModel model;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminPage frame = new AdminPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1288, 716);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(230, 230, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Welcome Admin");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(106, 11, 228, 55);
		contentPane.add(lblNewLabel);

		JButton btnNewButton = new JButton("Get Farmer Details");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(691, 24, 266, 33);
		contentPane.add(btnNewButton);

		JButton btnGetBidderDetails = new JButton("Get Bidder Details");
		btnGetBidderDetails.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnGetBidderDetails.setBounds(1007, 24, 266, 33);
		contentPane.add(btnGetBidderDetails);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(41, 125, 417, 476);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Crop ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(37, 68, 81, 28);
		panel_1.add(lblNewLabel_1);

		textField = new JTextField();
		textField.setBounds(197, 65, 146, 41);
		panel_1.add(textField);
		textField.setColumns(10);

		JButton btnNewButton_1 = new JButton("Bid Details");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = Integer.parseInt(textField.getText());
				JPanel panel = new JPanel();
				panel.setBounds(525, 150, 739, 203);
				contentPane.add(panel);
				panel.setLayout(null);

				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(141, 0, 452, 427);
				panel.add(scrollPane);

				table = new JTable();
				table.setModel(new DefaultTableModel(new Object[][] {},
						new String[] { "Crop ID", "Crop Name", "Bidder ID", "Bid Amount" }));
				table.getColumnModel().getColumn(1).setPreferredWidth(114);
				table.setBorder(new LineBorder(new Color(0, 0, 0)));
				scrollPane.setViewportView(table);
				model = new DefaultTableModel();
				Object[] column = { "Crop ID", "Crop Name", "Bidder ID", "Bid Price" };
				model.setColumnIdentifiers(column);
				table.setModel(model);

				CropDAO cropDaoObj = new CropDAOImplementation();
				boolean ans = cropDaoObj.soldOrNot(id);
				System.out.println("sold or not called");
				BiddingDAO biddingDAOObject = new BiddingDAOImplementation();
				if (ans) {

					List<BiddingEntity> bidList = biddingDAOObject.selectAllBiddingDetails(id);
					for (int i = 0; i < bidList.size(); i++) {
						BiddingEntity bidEntity = bidList.get(i);
						long intID = bidEntity.getCrop_id();
						String strCropName = bidEntity.getCrop_name();
						int intBidderID = bidEntity.getBidder_id();
						int amt = bidEntity.getBidAmount();
						Object row[] = { intID, strCropName, intBidderID, amt };
						model.addRow(row);
					}
					scrollPane.setViewportView(table);
					table.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "Crop Already Sold", "Alert", JOptionPane.WARNING_MESSAGE);
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");

				}

//				
				BiddingDAO biddingDaoObj = new BiddingDAOImplementation();
				BiddingEntity biddingEntity = biddingDaoObj.getDetails(id);

				System.out.println(biddingEntity.getBidAmount());
				System.out.println(biddingEntity.getBidder_id());

				textField_1.setText(biddingEntity.getCrop_name());
				String s = String.valueOf(biddingEntity.getBidder_id());
				textField_2.setText(s);
				String s1 = String.valueOf(biddingEntity.getBidAmount());
				textField_3.setText(s1);

				biddingDAOObject.getMaxBiddingAmountForCrop(id);

			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnNewButton_1.setBounds(10, 374, 139, 41);
		panel_1.add(btnNewButton_1);

		JLabel lblNewLabel_1_1 = new JLabel("Crop Name");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(10, 145, 108, 28);
		panel_1.add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_2 = new JLabel("Bidder ID");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_2.setBounds(23, 223, 95, 28);
		panel_1.add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_3 = new JLabel("Bid Amount");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_3.setBounds(10, 296, 108, 28);
		panel_1.add(lblNewLabel_1_3);

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(197, 142, 146, 41);
		panel_1.add(textField_1);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(197, 220, 146, 41);
		panel_1.add(textField_2);

		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(197, 293, 146, 41);
		panel_1.add(textField_3);

		JButton btnNewButton_1_1 = new JButton("Approve Bid");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				CropDAO cropDaoObj = new CropDAOImplementation();
				int farmer_id = cropDaoObj.selectFarmerId(Integer.parseInt(textField.getText()));

				System.out.println("Farmer id " + farmer_id);

				FarmerDAO farmerDaoObject = new FarmerDAOImplementation();
				FarmerEntity farmerEntity = new FarmerEntity();
				System.out.println("hey");
				farmerDaoObject.updateAmountFarmer(farmerEntity, farmer_id, Integer.parseInt(textField_3.getText()));
				System.out.println("amount of farmer final" + farmerEntity.getAmount());
				System.out.println(farmerEntity.getAmount());

				int bidder_id = Integer.parseInt(textField_2.getText());
				BidderDAO bidderDaoObj = new BidderDAOImplementation();
				BidderEntity bidderEntity = new BidderEntity();
				bidderDaoObj.updateAmountBidder(bidderEntity, bidder_id, Integer.parseInt(textField_3.getText()));
				System.out.println("amount of bidder final " + bidderEntity.getAmount());

				int crop_id = Integer.parseInt(textField.getText());
				CropDAO cropDaoObj1 = new CropDAOImplementation();
				cropDaoObj1.updateCropSoldStatus(crop_id);

				JOptionPane.showMessageDialog(null,
						"Your Crop " + textField.getText() + " " + textField_1.getText() + " is sold to Bidder "
								+ textField_2.getText() + "..... rs " + textField_3.getText()
								+ " creadited to your wallet..");

				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");

			}
		});
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnNewButton_1_1.setBounds(213, 374, 139, 41);
		panel_1.add(btnNewButton_1_1);
	}
}
