package service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dao.BiddingDAO;
import entities.BiddingEntity;

public class BiddingDAOImplementation extends BaseConnectionClass implements BiddingDAO {

	
	public BiddingDAOImplementation() {
		super();
	}

	
// 1] Method for inserting details...
	public void insertBiddingDetalis(BiddingEntity biddingEntity ) {
		
		
		try {
			PreparedStatement pst = 
					conn.prepareStatement("INSERT INTO BIDDING_DETAILS VALUES (?,?,?,?)");
			
			pst.setInt(1, biddingEntity.getCrop_id());
			pst.setString(2, biddingEntity.getCrop_name());
			pst.setInt(3, biddingEntity.getBidder_id());
			pst.setInt(4,biddingEntity.getBidAmount());
			
			System.out.println("PreparedStatement is created : "+ pst);
			
			//4. execute that statement 
			int rows = pst.executeUpdate();
			
			System.out.println("Rows created : "+rows);
			
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
	}

	
	
	
	
// 2] Method for getting maxBidAmount for particular crop
	@Override
	public int getMaxBiddingAmountForCrop(int cropId) {
		
        int maxBidAmount = 0;
     
        try 
        {
        	PreparedStatement pst = conn.prepareStatement("SELECT MAX(BID_AMOUNT) AS maxBidAmount FROM BIDDING_DETAILS WHERE CROP_ID = ? GROUP BY crop_id");
        	                                            // SELECT MAX(BID_AMOUNT) AS maxBidAmount FROM BIDDING_DETAILS  GROUP BY 301
        												// SELECT MAX(BID_AMOUNT) AS maxBidAmount FROM BIDDING_DETAILS WHERE CROP_ID = ?
        	pst.setInt(1, cropId);
        	
            ResultSet result = pst.executeQuery();
            if (result.next()) {
                maxBidAmount = result.getInt("maxBidAmount");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        	}

        return maxBidAmount;
    }
	
	
	
	
//3]Method for getting the biddingDetails for particular crop
	
	public List<BiddingEntity> selectAllBiddingDetails(int cropId) {
        List<BiddingEntity> biddingList = new ArrayList<>();
     
     
        try {
        	Statement statement = conn.createStatement();
			
			ResultSet result=statement.executeQuery("SELECT * FROM BIDDING_DETAILS WHERE CROP_ID = "+cropId);
			
            while (result.next()) 
            {
            	BiddingEntity biddingDetails = new BiddingEntity();
                biddingDetails.setCrop_id(result.getInt(1));
                biddingDetails.setCrop_name(result.getString(2));
                biddingDetails.setBidder_id(result.getInt(3));
                biddingDetails.setBidAmount(result.getInt(4));
                
                biddingList.add(biddingDetails);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return biddingList;
    }


//	4]getting other details for particular_crop of MaxBid 
	@Override
	public BiddingEntity getDetails(int cropID) {
		BiddingEntity biddingEntity=new BiddingEntity();
		   int amt = getMaxBiddingAmountForCrop(cropID);
		   System.out.println(amt);
		try {
			
        	Statement statement = conn.createStatement();
        	
			ResultSet result=statement.executeQuery("SELECT * FROM BIDDING_DETAILS WHERE CROP_ID = "+cropID+" and BID_AMOUNT= "+amt);
			
            while (result.next()) 
            {
            	biddingEntity.setCrop_id(cropID);
            	biddingEntity.setCrop_name(result.getString(2));
            	biddingEntity.setBidder_id(result.getInt(3));
            	biddingEntity.setBidAmount(result.getInt(4));
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return biddingEntity;
	}
	
}

