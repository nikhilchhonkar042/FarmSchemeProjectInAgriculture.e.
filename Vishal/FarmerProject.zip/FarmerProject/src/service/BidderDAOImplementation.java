package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dao.BidderDAO;
import entities.BidderEntity;
import entities.FarmerEntity;

public class BidderDAOImplementation extends BaseConnectionClass implements BidderDAO {
	Connection conn;

	public BidderDAOImplementation() {
		try {
			// 1. Load the Driver
//			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
//			System.out.println("Driver loaded....");

			// 2. Acquire the connection
//			System.out.println("Trying to connect....");
			conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
//			System.out.println("Connected : "+ conn);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void insertBidder(BidderEntity bidderEntity) {
		try {
			PreparedStatement pst = conn.prepareStatement(
					"INSERT INTO BIDDER_DETAILS(BIDDER_NAME,CONTACT_NO,EMAIL,ADDRESS,CITY,STATE,PINCODE,ACCOUNT_NO,IFSC,AADHAR_CARD,PAN_CARD,TRADING_CERTIFICATE,PASSWORD,BIDDER_WALLET) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			pst.setString(1, bidderEntity.getBidderName());
			pst.setString(2, bidderEntity.getPhoneNumber());
			pst.setString(3, bidderEntity.getEmail());
			pst.setString(4, bidderEntity.getArea());
			pst.setString(5, bidderEntity.getCity());
			pst.setString(6, bidderEntity.getState());
			pst.setString(7, bidderEntity.getPinCode());

			pst.setString(8, bidderEntity.getAccountNumber());
			pst.setString(9, bidderEntity.getIfscCode());

			pst.setString(10, bidderEntity.getAadharCard());
			pst.setString(11, bidderEntity.getPanCard());
			pst.setString(12, bidderEntity.getTradingCertificate());

			pst.setString(13, bidderEntity.getPassword());
//		   pst.setInt(0, 0);
			pst.setInt(14, 50000);

			int rows = pst.executeUpdate();

			System.out.println("Rows created : " + rows);
			System.out.println("added recoed");
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}

	}

	@Override
	public BidderEntity selectBidder(int id) {
		BidderEntity bidderEntity = new BidderEntity();
		try {

			Statement statement = conn.createStatement();

			ResultSet result1 = statement.executeQuery("Select  * from BIDDER_DETAILS WHERE BIDDER_ID=" + id);
			while (result1.next()) {
				bidderEntity.setBidderName(result1.getString(2));
				bidderEntity.setPhoneNumber(result1.getString(3));
				bidderEntity.setEmail(result1.getString(4));
				bidderEntity.setArea(result1.getString(5));
				bidderEntity.setCity(result1.getString(6));
				bidderEntity.setState(result1.getString(7));
				bidderEntity.setPinCode(result1.getString(8));
				bidderEntity.setAccountNumber(result1.getString(9));
				bidderEntity.setIfscCode(result1.getString(10));
				bidderEntity.setIfscCode(result1.getString(10));
				bidderEntity.setIfscCode(result1.getString(10));
				bidderEntity.setAadharCard(result1.getString(11));
				bidderEntity.setPanCard(result1.getString(12));
				bidderEntity.setTradingCertificate(result1.getString(13));
				bidderEntity.setPassword(result1.getString(14));
				bidderEntity.setAmount(result1.getInt(15));

			}
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}

		return bidderEntity;
	}

	@Override
	public void updateBidder(BidderEntity BidderEntity) {
	

	}

	@Override
	public void updateAmountBidder(BidderEntity bidderEntity, int bidder_id, int amt) {
		int n = 0;

		try {

			Statement statement = conn.createStatement();

			ResultSet result1 = statement
					.executeQuery("Select BIDDER_WALLET from BIDDER_DETAILS WHERE BIDDER_ID=" + bidder_id);
			while (result1.next()) {
				n = result1.getInt(1);
			}
			System.out.println("Original amt : " + n);
			int finalAmt = n - amt;
			PreparedStatement pst = conn.prepareStatement(
					"UPDATE BIDDER_DETAILS SET BIDDER_WALLET=" + finalAmt + " WHERE BIDDER_ID=" + bidder_id);

			System.out.println("PreparedStatement is created : " + pst);

			// 4. execute that statement // UR TABLENAME IS MYDEPT120
			pst.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void deleteBidder(int id) {
		// TODO Auto-generated method stub

	}

}
