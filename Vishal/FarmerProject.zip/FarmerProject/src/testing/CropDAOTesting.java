package testing;
import dao.CropDAO;
import entities.CropDetailsEntity;
import entities.FarmerEntity;
import service.CropDAOImplementation;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
public class CropDAOTesting {
 CropDAO cropDAO=new CropDAOImplementation();
 @Test
 public void selectTest() {
	 System.out.println("Test started..");
		Assertions.assertTrue(cropDAO!=null);
		System.out.println("Got the DAO : "+cropDAO);

		CropDetailsEntity cropEntity = cropDAO.selectCrop(301);
		
		System.out.println("CropEntity Obj : "+cropEntity);

		System.out.println("Test over...");
 }
 
 
}
