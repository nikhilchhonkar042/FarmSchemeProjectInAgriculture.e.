import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import dao.CropDAO;
import entities.CropDetailsEntity;
import service.CropDAOImplementation;

import dao.BiddingDAO;
import entities.BiddingEntity;
import service.BiddingDAOImplementation;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

public class AdminPage extends JFrame {

	private JPanel contentPane;
	private JTable table;
	DefaultTableModel model;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminPage frame = new AdminPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1288, 716);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(230, 230, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Welcome Admin");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(106, 11, 228, 55);
		contentPane.add(lblNewLabel);

		JButton btnNewButton = new JButton("Get Farmer Details");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(691, 24, 266, 33);
		contentPane.add(btnNewButton);

		JButton btnGetBidderDetails = new JButton("Get Bidder Details");
		btnGetBidderDetails.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnGetBidderDetails.setBounds(1007, 24, 266, 33);
		contentPane.add(btnGetBidderDetails);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(58, 125, 350, 226);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Crop ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(37, 68, 81, 28);
		panel_1.add(lblNewLabel_1);

		textField = new JTextField();
		textField.setBounds(146, 65, 146, 41);
		panel_1.add(textField);
		textField.setColumns(10);

		JButton btnNewButton_1 = new JButton("Bid Details");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = Integer.parseInt(textField.getText());
				JPanel panel = new JPanel();
				panel.setBounds(525, 150, 739, 203);
				contentPane.add(panel);
				panel.setLayout(null);

				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(141, 0, 452, 427);
				panel.add(scrollPane);

				table = new JTable();
				table.setModel(new DefaultTableModel(new Object[][] {},
						new String[] { "Crop ID", "Crop Name", "Bidder ID", "Bid Amount" }));
				table.getColumnModel().getColumn(1).setPreferredWidth(114);
				table.setBorder(new LineBorder(new Color(0, 0, 0)));
				scrollPane.setViewportView(table);
				model = new DefaultTableModel();
				Object[] column = { "Crop ID", "Crop Name", "Bidder ID", "Bid Price" };
				model.setColumnIdentifiers(column);
				table.setModel(model);
				BiddingDAO biddingDAOObject = new BiddingDAOImplementation();
				List<BiddingEntity> bidList = biddingDAOObject.selectAllBiddingDetails(id);
				for (int i = 0; i < bidList.size(); i++) {
					BiddingEntity bidEntity = bidList.get(i);
					long intID = bidEntity.getCrop_id();
					String strCropName = bidEntity.getCrop_name();
					int intBidderID = bidEntity.getBidder_id();
					int amt = bidEntity.getBidAmount();
					Object row[] = { intID, strCropName, intBidderID, amt };
					model.addRow(row);
				}
				scrollPane.setViewportView(table);
				table.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnNewButton_1.setBounds(78, 137, 139, 41);
		panel_1.add(btnNewButton_1);
	}
}
